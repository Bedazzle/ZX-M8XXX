# ctprobe — credits and licence

**ctprobe is not our work.** It is a ZX Spectrum program from the
[unreal-ng](https://github.com/alfishe/unreal-ng) project, vendored here with its
sources so it can run as one of our application tests.

| | |
|:--|:--|
| **ctprobe** | [alfishe/unreal-ng](https://github.com/alfishe/unreal-ng), `tools/verification/contention/ctprobe` |
| **Measuring engine** (`engine.asm`) | **Jan Bobrowski**'s zxtests engine, as adjusted by **Patrik Rak** for his Timing Test v0.3 — the same code, byte for byte, whose results were photographed on real 48K, 128K, +2A and +3 machines |
| **Licence** | **GNU GPL v3** — the full text is in `LICENSE` beside this file |
| **Upstream README** | the project's own documentation of what each check means, how a `BAD` line is worked out, and its results for other emulators: [ctprobe/README.md](https://github.com/alfishe/unreal-ng/tree/master/tools/verification/contention/ctprobe) |

`ctprobe.asm` + `engine.asm` are the sources `ctprobe.tap` was built from, included so
that distributing the binary carries its source as the GPL asks. `ctprobe.sym` lists
every label with its address, and `ctprobe-compare.py` turns a memory dump of a
finished run into a per-check breakdown.

**Relationship to ZX-M8XXX.** ctprobe is a separate program that happens to be *run
by* the emulator, exactly as the game and demo files in `tests/` are. Nothing in it is
compiled, linked or copied into ZX-M8XXX, and no ZX-M8XXX source is derived from it;
it is distributed alongside, and keeps its own licence and authorship. The GPL applies
to ctprobe, not to the emulator that loads it.

## Why it is here

It is the only instrument we have that sees **where inside an instruction** a memory
wait falls. A screen test cannot: it shows the result of thousands of instructions at
once, and `tests/*-test.html` checks our own model against our own expectations.
ctprobe times fragments at every start tick around the contention boundary against an
oracle computed from the published wait patterns and FUSE's cycle tables, and says
which of ~40 checks differ and by how many ticks.

Its report on ZX-M8XXX 26.09.03 is what started the contention work in v26.09.04:
215 wrong values on the 48K, 264 on the 128K. Both came from waits landing in the
wrong place inside indexed, block, stack and prefixed instructions, from the I/O cycle
being assumed to sit 7T into every `IN`/`OUT`, and from the floating bus being sampled
at the instruction's start tick.

## Running it

As an application test (Tools → Tests, or `python run-app-tests.py ctprobe`) it is
compared against a reference screen like any other. For the **number** instead — and
for a per-check breakdown — use the dedicated runner:

```
python run-ctprobe.py 48k 128k pentagon --tap tests/ctprobe/ctprobe.tap
python run-ctprobe.py 48k --tap tests/ctprobe/ctprobe.tap --dump-dir out
python tests/ctprobe/ctprobe-compare.py out/48k.bin
```

A count only means anything against the same probe build, and the probe's own README
marks check **P-05** as unconfirmed on real hardware — our remaining 128K failures are
all P-05, and are left alone deliberately.
